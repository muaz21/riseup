import React from 'react';
import WhyRiseUpSection from './components/WhyRiseUpSection';

const App: React.FC = () => {
  return (
    <main className="min-h-screen w-full flex flex-col items-center justify-center bg-gradient-to-b from-white to-blue-50/30">
      <WhyRiseUpSection />
    </main>
  );
};

export default App;